const booksData = require("./books")
const reviewsData = require("./reviews")

module.exports = {
books: booksData,
reviews : reviewsData
};